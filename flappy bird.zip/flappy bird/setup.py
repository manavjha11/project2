import cx_Freeze

executables = [cx_Freeze.Executable("main.py")]

cx_Freeze.setup(
    name="flappy bird",
    option={"build_exe":{"packages":["pygame"],"incluade_files":["background.png","base.png","bird.png","die.wav","hit.wav","message.wav","pipe.png","pipe1.png","point.wav","swoosh.wav","wing.wav"]}},
    description = "flappy bird",
    executables = executables
    )
