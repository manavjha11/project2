import pygame
import random

red = (200, 0, 0)
light_red = (255, 0, 0) 

black = (0, 0, 0)
white = (225, 225, 225)

yellow = (200, 200, 0)
light_yellow = (255, 255, 0)

green = (0, 115, 0)
light_green = (0, 225, 0)

blue = (0, 0, 115)
light_blue = (2, 251, 251)

# inicialiting pygame
pygame.init()

clock = pygame.time.Clock()

def img_load(img, x, y):
    img = pygame.image.load(img)
    screen.blit(img, [x, y])

# making display
screenheight = 511
screenwidth = 289
screen = pygame.display.set_mode((screenwidth, screenheight))

hit = pygame.mixer.Sound("hit.wav")
swoosh = pygame.mixer.Sound("swoosh.wav")
wing = pygame.mixer.Sound("wing.wav")
point = pygame.mixer.Sound("point.wav")
die = pygame.mixer.Sound("die.wav")

# displaytext

ssmallfont = pygame.font.SysFont("comicsansms", 30)
smallfont = pygame.font.SysFont("comicsansms", 32)
midfont = pygame.font.SysFont("comicsansms", 40)
largefont = pygame.font.SysFont("comicsansms", 70)

def text(text, color, textx, texty, font):
    text = font.render(text, True, color)
    screen.blit(text, [textx, texty])

def gameover():
    run = True

    while run:
        for event in pygame.event.get():
            if event == pygame.QUIT:
                run = False
                pygame.quit()
                quit()

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    gameloop()    

        text("gameover", red, 50, 170, midfont)
        text("tap to play again ", black, 20, 250, smallfont)


        pygame.display.update()

                

def gameintro():
    game = True

    while game:
        for event in pygame.event.get():
            if event == pygame.QUIT:
                run = False
                pygame.quit()
                quit()

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    gameloop()

        screen.fill(white)
        img_load("background.png", 0, 0)
        img_load("bird.png", 60, 240)
        img_load("message.png", 0, 0)

        pygame.display.update()
        clock.tick(2)

 
# calc loop
def gameloop():
    
    run = True
    score = 0
    playerx = 60
    playery = 250
    playerymove = 0
    colloid = False

    pipe1x = 400
    pipe1y = random.randrange(-190, -180) 
    
    pipex = 400
    pipey = random.randrange(320, 360)
    
    pipe1xmove = 0
    pipexmove = 0
    
    pipe2x = 750
    pipe2y = random.randrange(-300, -290)
    
    pipe3x = 750
    pipe3y = random.randrange(200, 240)
    
    pipe2xmove = 0
    pipe3xmove = 0

    while run:

        for event in pygame.event.get():
            if event == pygame.QUIT:
                run = False
                pygame.quit()
                quit()

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    wing.play()
                    playerymove = -12
                    pipe1xmove = -5
                    pipexmove = -5
                    pipe2xmove = -5
                    pipe3xmove = -5

            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_SPACE:
                    playerymove = 9
                    pipe1xmove = -5
                    pipexmove = -5
                    pipe2xmove = -5
                    pipe3xmove = -5
                    
        playery += playerymove
        pipe1x += pipe1xmove
        pipex += pipexmove
        pipe2x += pipe2xmove
        pipe3x += pipe3xmove

        if playery < 0:
            hit.play()
            gameover()
        elif playery > 376:
            hit.play()
            gameover()

        pipe_height = pygame.image.load("pipe.png").get_height()
        pipe_width = pygame.image.load("pipe.png").get_width()

        player_height = pygame.image.load("bird.png").get_height()
        player_width = pygame.image.load("bird.png").get_width()

        
        

        if playerx + 9 > pipex + 70 > playerx:
            point.play()
            score += 1
            
        elif playerx + 9 > pipe2x + 70 > playerx:
            point.play()
            score += 1

        pipe1rx = pipe1x + 53
        pipe1ry = pipe1y + 5

        pipe2rx = pipe2x + 53
        pipe2ry = pipe2y + 5

        pipe3rx = pipe3x + 47
        pipe3ry = pipe3y + 24

        piperx = pipex + 47
        pipery = pipey + 24

        img_load("background.png", 0, 0)
        
        rect1 = pygame.draw.rect(screen, black, [pipe1rx, pipe1ry, 100, 400])
        rect1 = pygame.draw.rect(screen, black, [pipe2rx, pipe2ry, 100, 400])
        rect1 = pygame.draw.rect(screen, black, [pipe3rx, pipe3ry, 100, 400])
        rect1 = pygame.draw.rect(screen, black, [piperx, pipery, 100, 400])
        img_load("pipe.png", pipe1x, pipe1y)
        img_load("pipe1.png", pipex, pipey)
        img_load("pipe.png", pipe2x, pipe2y)
        img_load("pipe1.png", pipe3x, pipe3y)
        img_load("bird.png", playerx, playery)

        if pipe1rx + 100 > playerx + 30 > pipe1rx and pipe1ry + 400 > playery > pipe1ry:
            hit.play()
            gameover()

        if pipe2rx + 100 > playerx + 30 > pipe2rx and pipe2ry + 400 > playery > pipe2ry:
            hit.play()
            gameover()

        if pipe3rx + 100 > playerx + 30 > pipe3rx and pipe3ry + 400 > playery + 21 > pipe3ry:
            hit.play()
            gameover()

        if piperx + 100 > playerx + 30 > piperx and pipery + 400 > playery + 21 > pipery:
            hit.play()
            gameover()    

        if pipe1x == -160 and pipex == -160:
            pipe1x = 410
            pipex = 410
            pipe1y = random.randrange(-210, -190)
            pipey = random.randrange(320, 360) 
        
        if pipe2x == -160 and pipe3x == -160:
            pipe2x = pipe1x + 290
            pipe3x = pipex + 290
            pipe2y = random.randrange(-300, -290)
            pipe3y = random.randrange(200, 240)
            
        text(str(score), black, 125, 50, largefont)
        
        pygame.display.update()

    


gameintro()









        
